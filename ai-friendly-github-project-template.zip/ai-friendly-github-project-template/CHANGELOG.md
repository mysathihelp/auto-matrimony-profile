# Changelog

## v0.1.0
- Initial AI-friendly GitHub structure setup.
