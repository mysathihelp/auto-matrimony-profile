# AI-Friendly GitHub Project Template

Use this project as a base to keep ChatGPT aware of your full structure while coding.

## Usage
1. Upload this folder to your GitHub repository.
2. Start every ChatGPT prompt with:
   "Refer to blueprint.md for full structure."
3. Then specify the file you’re editing and the task.

## Why It Helps
- ChatGPT remembers your structure from blueprint.md
- Prevents confusion when editing large projects
- Keeps consistent logic across all files
